package com.officer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;
import java.util.TimerTask;
import java.util.zip.ZipOutputStream;

import javax.servlet.RequestDispatcher;


import org.omg.CORBA.Request;

import com.database.conn.Methods;
import com.manager.Admin;

import com.util.HashingTechnique;

import symmetric_AES.AESCrypt;


public class RandomTimernew extends TimerTask 
{
	
	 public static Object getRespose;
	 int n=0;
	 public static boolean msg_status=false;
	 	public static String getRespose(String reqUrl)
	     {
	     	String response = "";
	     	BufferedReader in = null;
	
	     	try 
	     	{

	 	        //URL urldemo = new URL("http://www.google.com/");
	 	        URL url = new URL(reqUrl);
	 	        URI uri = new URI(url.getProtocol(), url.getUserInfo(), url.getHost(), url.getPort(), url.getPath(), url.getQuery(), url.getRef());
	 	        url = uri.toURL();
	 	        URLConnection con = url.openConnection();
	 	        in = new BufferedReader(new InputStreamReader(con.getInputStream()));
	 	      
	 	        StringBuffer sb = new StringBuffer("");
	             String line = "";
	             String NL = System.getProperty("line.separator");
	             while ((line = in.readLine()) != null) 
	             {
	                 sb.append(line + NL);
	             }
	             response = sb.toString();
	 	        	
	 		} 
	     	catch (Exception e) 
	     	{
	 			System.out.println("Opps,Exception In CustomUrlResponse==>getRespose(String url)");
	 			e.printStackTrace();
	 		}
	     	finally
	     	{
	     		try 
	     		{
	 				in.close();
	 			}
	     		catch (IOException e) 
	     		{
	 				e.printStackTrace();
	 			}
	     	}
	     	
	     	return response;
	     }







		private String hashtag="";
	 	
	 	
	 	
	 	
	 	
	 	
	
	    public void run() 
	    { 
	    	
	    	
	  
			ArrayList<Integer> boothno=new ArrayList<Integer>();
	    	try 
	    	{
	         
				try 
				{
					boothno=Admin.getboothvalues();
					System.out.println(">>>>>>boothno>>>>>>>>>>>>>>>>"+boothno);
				} catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
	    	catch (ClassNotFoundException e1)
             {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	    	int element;
	    	ArrayList<Integer> randvalue=new ArrayList<Integer>();
	    	
	    	for(int j=0;j<boothno.size();j++)
	    	{
	    		
	    		element=	boothno.get(j);
	    		randvalue.add(element);
	    	System.out.println("element is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+element);
	    	

			String record = null;
			try {
				record = Admin.getrecordsno(element);
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
				System.out.println("record>>>>>>>>>>>>>"+record);
				
	
			String record1 = null;
			try {
				record1 = Admin.getrecords1(element);
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
				System.out.println("record1>>>>>>>>>>>>>"+record1);
				

				String record2 = null;
				try {
					record2 = Admin.getrecords2(element);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					System.out.println("record2>>>>>>>>>>>>>"+record2);
					

					String record3 = null;
					try {
						record3 = Admin.getrecords3(element);
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
						System.out.println("record3>>>>>>>>>>>>>"+record3);
						

			
						String record4 = null;
						try {
							record4 = Admin.getrecords4(element);
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
							System.out.println("record4>>>>>>>>>>>>>"+record4);
						 	
						    String packet=record1+"_"+record2+"_"+record3+"_"+record4;

					
	 /*   
	    	
	    String encrypted="";
        
        AESCrypt  encrypter = new AESCrypt();
       	try 
       	{
				encrypted = encrypter.encrypt(packet);
			} 
       	catch (Exception e)
       	{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
       	System.out.println("Encrypted File is>>>>>>>>>>>>>>>>>>>>>>>>"+encrypted);*/
 
     
       	try
       	{

      	/* Uploading File On Cloud (Starts)*/
			String ftpserver = "ftp.drivehq.com";
	        String ftpusername = "Danush2001";
	        String ftppassword = "*Danush123";
       	
			
       	  
	    	 String dirToUploadFile="Evoting";

       	
	    	 String blockname="block";
	 
			   String hashtagpath = "C:\\Users\\kusha\\OneDrive\\Desktop\\Testing\\"+element+"_"+blockname+".txt";
			   
			  
			   System.out.println("File Path :"+hashtagpath);
			   FileWriter fstream = new FileWriter(hashtagpath);
				
				BufferedWriter out1 = new BufferedWriter(fstream);

		        out1.write(packet);
		        out1.close();
		        
		        File f = new File(hashtagpath);
		        //////////////////
		     String   vall= Admin.gettotal();
		     int i= Integer.parseInt(vall);
		     System.out.println("jkjjjjjjjjjjjjjjjjjjjj"+i);
		     
		 
		      //Hash Function Start//
		        
		        HashingTechnique g1 = new HashingTechnique();
		        hashtag = g1.MD5(hashtagpath);
				   
			        //End//
		        
		        
	        
	           //Random Function for nonce //
		        Random r = new Random();
			    String randomNumber = String.format("%04d", (Object) Integer.valueOf(r.nextInt(1001)));
			    System.out.println("randomNumber>>>>>>>>>>>>>>>>>>>>>>>>"+randomNumber);
			    //End
	        
			  //  FileUpload.upload(filename,file,destFilePath);
		        System.out.println("uploadded success>>>>>>>>>>>>>>>");
	        
	         
			
			/* Adding the upload Transaction details (Start)*/
			
			/*boolean flag = false;
			int dotPos = filename.lastIndexOf(".");
		    String extension = filename.substring(dotPos);
		    String fileType=extension;*/
			
			Calendar currentDate = Calendar.getInstance();
			SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
			SimpleDateFormat formatter1=new SimpleDateFormat("HH:mm:ss");
			String date = formatter.format(currentDate.getTime());
			String time = formatter1.format(currentDate.getTime());
			
			date = date + "  " + time;
			System.out.println("date is>>>>>>>>>>>>>>>>"+date);
	
			
			String previousblk=Methods.previousblkid();
			System.out.println("genesisblk id is>>>>>>>>>>>>>>>>>>"+previousblk);
			
			
			String previousblkvale=Methods.previousblk( previousblk);
			

		    int id  =  Methods.getTransID();
		    int fileid=id+1;
			
			
		        
		        //Confidential Key Creation Start//
	
		        
		        String value=""+previousblkvale+"~"+date+"~"+""+randomNumber+"~"+hashtag;
				   
				   System.out.println("Input :"+value);
				   
				 
		
				   String ConfidentialFilePath = "C:\\E_voting\\E_onlinevote_new_v3\\ConfidentialKeys\\"+"C_"+fileid+".txt";
				   
				  
				   System.out.println("File Path :"+ConfidentialFilePath);
				   FileWriter fstream1 = new FileWriter(ConfidentialFilePath);
					
					BufferedWriter out11 = new BufferedWriter(fstream1);

			        out11.write(value);
			        out11.close();
			        
			        File f1 = new File(ConfidentialFilePath);
			        
			        String fnm = f1.getName();
			  
			   	 System.out.println("short filename>>>>>>>>>>>"+f.getAbsolutePath().substring(f.getAbsolutePath().lastIndexOf("\\")+1));
			        
			        //End//
			        
			     String shortpath=f.getAbsolutePath().substring(f.getAbsolutePath().lastIndexOf("\\")+1);
			 
		        ///////////////
		        System.out.println("file is>>>>>>>>>>>>>>>>>>"+f);
		        String fnm1 = f.getName();
	    	 
	    	 
		    
					String zipblkame=element+"_"+blockname+".zip";
					System.out.println("zipblkame>>>>>>>>>>>>>"+zipblkame);
		        

		   
		        
		        File newFile = new File(zipblkame);
	            System.out.println("newfile>>>>>>>>>>>>>>>>>>>"+newFile);
	            FileOutputStream fos = new FileOutputStream(newFile);
	            System.out.println("fos>>>>>>>>>>>>>>>>>>>>"+fos);
	            
	            
	            
	            
	        
				ZipOutputStream zos = new ZipOutputStream(fos);

				//String file1Name = ConfidentialFilePath;
				//System.out.println("file1Name>>one>>>>>>>>>>>>>>>"+file1Name);
				String file2Name = hashtagpath;
				System.out.println("file1Name>>>>>two>>>>>>>>>>>>"+file2Name);
				String file1Name = ConfidentialFilePath;

				//FileUpload.addToZipFile(file1Name, zos);
				FileUpload.addToZipFile(file1Name, zos);
				FileUpload.addToZipFile(file2Name, zos);
				
				zos.close();
				fos.close();
		
	
       	  
	    	FileUpload.upload(ftpserver,ftpusername,ftppassword,zipblkame,newFile,dirToUploadFile);
		
       	  
       	  
       	  
       	
       	
       	
     	boolean flag=Admin.insertblockname(record,zipblkame);
     	if(flag == true){
    	flag = Methods.addUploadTransaction(fileid,date,previousblkvale,hashtag,zipblkame,randomNumber); 
     	}
     	
       	}
       	catch (Exception e)
       	{
			// TODO: handle exception
       		System.out.println(e);
		}
	    	
	    	

	    
	    }

	    }
	  
}
