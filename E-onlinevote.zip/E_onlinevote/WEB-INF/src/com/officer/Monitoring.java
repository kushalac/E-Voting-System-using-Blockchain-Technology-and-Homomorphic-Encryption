package com.officer;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.manager.Admin;





public class Monitoring extends HttpServlet
{
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException
		{
	Boolean flag=false;
	System.out.println("its came inside monitoring servlet");
	

	try
	{

		Admin.deleteAllBlocks();
		Admin.deleteVotes();
		Admin.deleteFileUpload();
		String reqUrl=req.getParameter("reqUrl");
		System.out.println("submit>>>>>>>>>>>>>>>>>>>>>>"+reqUrl);


		RandomTimernew testTimertask = new RandomTimernew();
	    long interval =1 * 30 * 1000;
	    final Timer testTimer = new Timer();
	 
	    testTimer.schedule(testTimertask,1000,interval);
	    
	    HttpSession session = req.getSession();

	    session.setAttribute("testTimer", testTimer);
	    
	 /*   TimerTask stopTask = new TimerTask() {
            public void run() {
            	  testTimer.cancel();
                System.out.println("Timer stopped.");
                
                try {
                	Admin.deleteBlock();
					Admin.deleteVotes();
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
              
                }
        };
        testTimer.schedule(stopTask, 150000);
		*/
		
		RequestDispatcher rd=req.getRequestDispatcher("/Files/JSP/officer/Monitoring.jsp");
		rd.forward(req, resp);
		
	}
	catch(Exception e)
	{
		System.out.println(e);
		
	}
}
	

}
	
	
	

