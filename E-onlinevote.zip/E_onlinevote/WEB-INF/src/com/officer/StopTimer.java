package com.officer;

import java.io.IOException;
import java.util.Timer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.manager.Admin;

public class StopTimer extends HttpServlet {
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
			{
		Boolean flag=false;
		System.out.println("its came inside stop timer servlet");
		

		try
		{
			HttpSession session = req.getSession();
			
			Timer testTimer = (Timer) session.getAttribute("testTimer");

			// Cancel the timer
			testTimer.cancel();

			// Delete some data
			Admin.deleteBlock();
			Admin.deleteVotes();
		
			System.out.println("Timer Stopped");

			RequestDispatcher rd=req.getRequestDispatcher("/Files/JSP/officer/Officerhome.jsp?no=1");
			rd.forward(req, resp);
		
			
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
			}

}
