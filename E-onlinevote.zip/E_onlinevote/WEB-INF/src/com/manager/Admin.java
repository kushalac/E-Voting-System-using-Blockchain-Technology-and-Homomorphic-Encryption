/**
 * 
 */
package com.manager;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Vector;

import com.database.conn.DBConnection;




public class Admin 
{
	private static Connection connection = null;
	private static Statement statement = null;
	private static ResultSet resultSet = null;
	private static String vno="";
	
	public boolean loginCHK(String name, String pass) 
	{
		boolean flag=false;
		try
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
			resultSet = st.executeQuery("select * from adminlogin where adminid='"+name+"' and password='"+pass+"'");
			while(resultSet.next())
			{
				flag=true;
			}
			System.out.println("Admin Login Status : "+flag);
		}
		catch(Exception e)
		{
			System.out.println("Opp's Error is in AdminDAO.loginCHK()....."+e);
		}
		return flag;
	}
	
	
	public static boolean insertblockname(String tc, String bname) 
	{
		boolean flag=false;
		try
		{
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			String sql="insert into m_bc_votes(T_no,blockname)values('"+tc+"','"+bname+"')";
			System.out.println(sql);
			int i=st.executeUpdate(sql);
			if(i!=0)
			{
				flag=true;
			}
			System.out.println("User Registeration Status : "+flag);
		}
		catch(Exception e)
		{
			System.out.println("Opp's Error is in AdminDAO-register()....."+e);
		}
		return flag;
	}
	
	
	
	
	
	
	
	public static boolean insertrecords(String ccode, String bcode,String edcode, String Nvote) 
	{
		boolean flag=false;
		try
		{
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			String sql="insert into m_votes(C_code,B_code,E_D_code,No_votes)values('"+ccode+"','"+bcode+"','"+edcode+"','"+Nvote+"')";

			System.out.println(sql);
			int i=st.executeUpdate(sql);
			if(i!=0)
			{
				flag=true;
			}
			System.out.println("User Registeration Status : "+flag);
		}
		catch(Exception e)
		{
			System.out.println("Opp's Error is in AdminDAO-register()....."+e);
		}
		return flag;
	}
	
	
	
	
	public static ArrayList getrecordvalues() throws SQLException, ClassNotFoundException
	{
		
		
		
		int n=0;
		try 
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
			resultSet=st.executeQuery("select count(T_no) from m_votes");
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		while(resultSet.next())
		{
			n=resultSet.getInt(1);
		}
		System.out.println("no of voters>>>>>>>>>>>>>:" +n);

		
	ArrayList<Integer> numbers = new ArrayList<Integer>();
	     for(int i = 0; i < n; i++)
	     {
	    	 numbers.add(i+1);
	     }
	 
	  
	 
		return numbers;
		
	}
	
	
	
	public static ArrayList getboothvalues() throws SQLException, ClassNotFoundException
	{
		
		ArrayList<Integer> numbers = new ArrayList<Integer>();
		
		int n=0;
		try 
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
			resultSet=st.executeQuery("select T_no from m_votes");
			
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		while(resultSet.next())
		{
			numbers.add(resultSet.getInt(1));
		}
		System.out.println("no of voters>>>>>>>>>>>>>:" +n);

		
/*	ArrayList<Integer> numbers = new ArrayList<Integer>();
	     for(int i = 0; i < n; i++)
	     {
	    	 numbers.add(i+1);
	     }
	 */
	  
	 
		return numbers;
		
	}
	
	
	
	
	public static ArrayList getboothnos() throws SQLException, ClassNotFoundException
	{
		
		
		ArrayList<Integer> numbers = new ArrayList<Integer>();
		int n=0;
		try 
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
			resultSet=st.executeQuery("select T_no from m_bc_votes");
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		while(resultSet.next())
		{
			numbers.add(resultSet.getInt(1));
		}
		System.out.println("no of voters>>>>>>>>>>>>>:" +n);

		
	
	
	  
	 
		return numbers;
		
	}
	public static ArrayList<String> getrecords(int elem) throws SQLException, ClassNotFoundException
	{
		
		ArrayList<String> numbers = new ArrayList<String>();
		//ArrayList<String> result=null;
		int n=0;
		try 
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
			resultSet=st.executeQuery("select * from m_votes where T_no='"+elem+"'");
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		while(resultSet.next())
		{
			
			numbers.add(resultSet.getString(2));
			numbers.add(resultSet.getString(3));
			numbers.add(resultSet.getString(4));
			numbers.add(resultSet.getString(5));
			//n=resultSet.getInt(1);
		}
		

	/*	
	ArrayList<String> numbers = new ArrayList<String>();
	     for(int i = 0; i < n; i++)
	     {
	    	 numbers.add(i+1, null);
	     }
	 */
	  

		return numbers;
		
	}
	
	
	
	
	public static String getrecordsno(int elem) throws SQLException, ClassNotFoundException
	{
		
		
		String numbers="";
		int n=0;
		try 
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			String sql = "select * from m_votes where T_No='"+elem+"'";
			
			System.out.println("THE VALUE OF ELEMENT "+sql);
			
			resultSet=st.executeQuery("select * from m_votes where T_No='"+elem+"'");
			
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		while(resultSet.next())
		{
			
			numbers=resultSet.getString(1);
		
		
		}
		

	
		return numbers;
		
	}
	
	
	
	
	
	
	public static String getrecordblock(int elem) throws SQLException, ClassNotFoundException
	{
		
		
		String numbers="";
		int n=0;
		try 
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			Statement st1=con.createStatement();
			
			resultSet=st.executeQuery("select * from m_bc_votes where T_no='"+elem+"'");
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		while(resultSet.next())
		{
			
			numbers=resultSet.getString(2);
		
		
		}
		


		return numbers;
		
	}
	
	
	
	public static String getrecords1(int elem) throws SQLException, ClassNotFoundException
	{
		
		//ArrayList<String> numbers = new ArrayList<String>();
		//ArrayList<String> result=null;
		String numbers="";
		int n=0;
		try 
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
			resultSet=st.executeQuery("select * from m_votes where T_no='"+elem+"'");
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		while(resultSet.next())
		{
			
			numbers=resultSet.getString(2);
		
		
		}
		


		return numbers;
		
	}
	
	
	public static String getrecords2(int elem) throws SQLException, ClassNotFoundException
	{
		
		//ArrayList<String> numbers = new ArrayList<String>();
		//ArrayList<String> result=null;
		String numbers="";
		int n=0;
		try 
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
			resultSet=st.executeQuery("select * from m_votes where T_no='"+elem+"'");
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
	    while(resultSet.next())
		{
			
	    	numbers=resultSet.getString(3);
		
		
		}
		


		return numbers;
		
	}
	
	
	public static String getrecords3(int elem) throws SQLException, ClassNotFoundException
	{
		
		//ArrayList<String> numbers = new ArrayList<String>();
		//ArrayList<String> result=null;
		String numbers="";
		int n=0;
		try 
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
			resultSet=st.executeQuery("select * from m_votes where T_no='"+elem+"'");
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		while(resultSet.next())
		{
			
			numbers=resultSet.getString(4);
		
		
		}
		


		return numbers;
		
	}
	
	
	public static String getrecords4(int elem) throws SQLException, ClassNotFoundException
	{
		
		//ArrayList<String> numbers = new ArrayList<String>();
		String numbers="";
		//ArrayList<String> result=null;
		int n=0;
		try 
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
			resultSet=st.executeQuery("select * from m_votes where T_no='"+elem+"'");
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		while(resultSet.next())
		{
			
			numbers=resultSet.getString(5);
		
		
		}
		


		return numbers;
		
	}

	
	public static String getrecords5(int elem) throws SQLException, ClassNotFoundException
	{
		
		//ArrayList<String> numbers = new ArrayList<String>();
		String numbers="";
		//ArrayList<String> result=null;
		int n=0;
		try 
		{
			
			Connection con;
			Statement st;
			ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
			resultSet=st.executeQuery("select * from m_votes where T_no='"+elem+"'");
		} 
		catch (SQLException e) 
		{
			System.out.println(e);
		}
		while(resultSet.next())
		{
			
			numbers=resultSet.getString(5);
		
		
		}
		


		return numbers;
		
	}



	public static ResultSet selecteventype(int sno)
	{	ResultSet rs=null;
		
		
		try
		{
			Connection con;
			Statement st;
		//	ResultSet rs;

			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
	
			
			String sql="select * from m_votes where T_no='"+sno+"'";
			
           rs= st.executeQuery(sql);
		/*	while(rs.next())
			{
				//String vno=rs.getString(1);
				System.out.println("vno in db>>>>>>>>>>>>>>>>>"+vno);
			}*/
			
		
		}
		catch(Exception e)
		{
			System.out.println("Exception in DAO: "+ e);
		}
		
		return rs;
	}


	public static String gettotal() {
		try
		{
			Connection con;
			Statement st;
			ResultSet rs;
		
			con=DBConnection.getServerConnection();
			st=con.createStatement();
			
	
			
			String sql="select count(*) from m_votes";
		rs= st.executeQuery(sql);
			while(rs.next())
			{
				 vno=rs.getString(1);
				System.out.println("vno in db>>>>>>>>>>>>>>>>>"+vno);
			}
			
		
		}
		catch(Exception e)
		{
			System.out.println("Exception in DAO: "+ e);
		}
		
		return vno;
	}


	public static boolean deleteBlocks() throws SQLException {
		// TODO Auto-generated method stub
		
		
		Connection con;
		Statement st;
		ResultSet rs;
	
		con=DBConnection.getServerConnection();
		  String query = "TRUNCATE TABLE m_bc_votes";
		  st=con.createStatement();
		  st.executeUpdate(query);
	         
	         System.out.println("Table emptied successfully!");
		return false;
	}

	public static boolean deleteVotes() throws SQLException {
		// TODO Auto-generated method stub
		
		
		Connection con;
		Statement st;
		ResultSet rs;
	
		con=DBConnection.getServerConnection();
		  String query = "TRUNCATE TABLE m_votes";
		  st=con.createStatement();
		  st.executeUpdate(query);
	         
	         System.out.println("Table emptied successfully!");
		return false;
	}


	public static void deleteBlock() throws SQLException {
		

		Connection con;
		Statement st;
		ResultSet rs;
	
		con=DBConnection.getServerConnection();
		 String subquery = "SELECT T_NO FROM m_votes";
		    String deleteQuery = "DELETE FROM m_bc_votes WHERE T_NO NOT IN (" + subquery + ")";
		    
		    Statement stmt = con.createStatement();
		    stmt.executeUpdate(deleteQuery);
		    
		    con.close();
		// TODO Auto-generated method stub
		
	}


	public static void deleteAllBlocks() throws SQLException {
		// TODO Auto-generated method stub

		Connection con;
		Statement st;
		ResultSet rs;
	
		con=DBConnection.getServerConnection();
		
		    String deleteQuery = "DELETE FROM m_bc_votes ";
		    
		    Statement stmt = con.createStatement();
		    stmt.executeUpdate(deleteQuery);
		    
		    con.close();
		
	}


	public static void deleteFileUpload() throws SQLException {
		// TODO Auto-generated method stub
		Connection con;
		Statement st;
		ResultSet rs;
	
		con=DBConnection.getServerConnection();
		
		    String deleteQuery = "DELETE FROM m_file_upload ";
		    
		    Statement stmt = con.createStatement();
		    stmt.executeUpdate(deleteQuery);
		    
		    con.close();
		
	}

	
	
}
