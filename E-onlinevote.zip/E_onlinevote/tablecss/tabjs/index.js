$(function(){
  $('#keywords').tablesorter(); 
});