package org.apache.jsp.Files.JSP.manager;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.sql.*;
import com.database.conn.*;
import com.database.conn.DBConnection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.*;
import com.database.conn.*;
import com.paillier.*;
import java.math.BigInteger;

public final class Currentstatus_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


		Connection con=DBConnection.getServerConnection();
		Statement st=null;
		ResultSet rs=null;
		String b_no=null;
		String b_ref_no=null;
		String b_location=null;
	

		Connection con1=null;
		Statement st1=null;
		ResultSet rs1,rs2=null;
		String sql1="";
		String sql2="";
		String e_d_code=null;
		BigInteger n=new BigInteger("0");
		String empty_code=null;

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/Files/JSP/manager/Manager_content.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("     \r\n");
      out.write("    \r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write(" \r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("<html>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<SCRIPT type=\"text/javascript\">\r\n");
      out.write("  \twindow.history.forward();\r\n");
      out.write("   \tfunction noBack() { window.history.forward(); }\r\n");
      out.write("</SCRIPT>\r\n");
      out.write("\r\n");
      out.write("<head>\r\n");
      out.write("\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("</head>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<link rel=\"Stylesheet\" type=\"text/css\" href=\"");
      out.print(request.getContextPath());
      out.write("/Files/CSS/Officer.css\">\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<body style=\"background-color:#32a87d;\">\r\n");
      out.write("\t\r\n");
      out.write("\t");
      out.write("\r\n");
      out.write("\t\r\n");
      out.write("\t<div id=\"header\">\r\n");
      out.write("\t\t<br><br>\t\t\t\t\r\n");
      out.write("\t\t<center>\r\n");
      out.write("\t\t\t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/index/title.png\"><br><br>\r\n");
      out.write("\t\t</center>\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t</div>\r\n");
      out.write("\t\r\n");
      out.write("\t");
      out.write("\t\r\n");
      out.write("\t \r\n");
      out.write("\t<div align=\"right\">\r\n");
      out.write("\t\t<form action=\"");
      out.print(request.getContextPath());
      out.write("/Logout\" method=\"post\">\r\n");
      out.write("\t\t    \r\n");
      out.write("\t\t\t<a href=\"");
      out.print(request.getContextPath());
      out.write("/Files/JSP/manager/Managerhome.jsp\">\r\n");
      out.write("\t\t\t\t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/home.png\" height=\"30\" width=\"30\"></a>\r\n");
      out.write("\t\t\t\t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/line.png\" height=\"30\" width=\"5\">\r\n");
      out.write("\t\t\t<a href=\"");
      out.print(request.getContextPath());
      out.write("/Files/JSP/manager/Manager_ChangePassword.jsp\">\r\n");
      out.write("\t\t\t\t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/changepwd.png\"\r\n");
      out.write("\t\t\t\t\tonmouseover=\"this.src='");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/changepwd-click.png'\"\r\n");
      out.write("   \t   \t \t\t\tonmouseout=\"this.src='");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/changepwd.png'\"></a>\r\n");
      out.write("\t\t\t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/line.png\" height=\"30\" width=\"5\">\t\t\r\n");
      out.write("\t\t\t<input type=\"image\" value=\"submit\" src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/logout.png\"\r\n");
      out.write("\t\t\t\t\tonmouseover=\"this.src='");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/logout-click.png'\"\r\n");
      out.write("   \t   \t \t\t\tonmouseout=\"this.src='");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/logout.png'\">\t\r\n");
      out.write("\t\t\t&emsp;&emsp;\r\n");
      out.write("\t\t</form>\t\r\n");
      out.write("\t</div>\t\r\n");
      out.write("\t\r\n");
      out.write("\t");
      out.write("\r\n");
      out.write("\t\r\n");
      out.write("\t");
      out.write("\t\r\n");
      out.write("\t");

		String manager_id=(String)request.getSession().getAttribute("x_manager_id");
		rs=Methods.ManagerBooth(manager_id);
		while(rs.next())
		{
			b_no=rs.getString(1);
			b_ref_no=rs.getString(2);
			b_location=rs.getString(3);
		}		
	
      out.write("\t\r\n");
      out.write("\t\r\n");
      out.write("\t");
      out.write("\r\n");
      out.write("\t\r\n");
      out.write("\t<div id=\"sidebar\">\r\n");
      out.write("\t\t<center><br><br>\r\n");
      out.write("\t\t\t<table>\r\n");
      out.write("\t\t\t\t");
      out.write("\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td>\r\n");
      out.write("\t\t\t\t\t\t<a href=\"");
      out.print(request.getContextPath());
      out.write("/Files/JSP/manager/VoterDetails.jsp\" >\t\r\n");
      out.write("   \t\t\t\t\t\t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/voterdetails.png\" \r\n");
      out.write("   \t\t\t\t\t\t\tonmouseover=\"this.src='");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/voterdetails-click.png'\"\r\n");
      out.write("   \t   \t \t\t\t\t\tonmouseout=\"this.src='");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/voterdetails.png'\"/></a>\r\n");
      out.write("   \t   \t \t\t\t</td>\r\n");
      out.write("   \t   \t \t\t</tr>\r\n");
      out.write("   \t   \t \t\t<tr>\r\n");
      out.write("   \t   \t \t\t\t<td>\r\n");
      out.write("   \t   \t \t\t\t\t<form action=\"");
      out.print(request.getContextPath());
      out.write("/VotingProcess\" method=\"post\">\t\r\n");
      out.write("   \t\t\t\t\t\t\t<input type=\"image\" src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/information.png\" \r\n");
      out.write("   \t\t\t\t\t\t\t\t\tonmouseover=\"this.src='");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/information-click.png'\"\r\n");
      out.write("   \t   \t \t\t\t\t\t\t\tonmouseout=\"this.src='");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/information.png'\"/>\r\n");
      out.write("   \t   \t \t\t\t\t</form>\r\n");
      out.write("   \t   \t \t\t\t</td>\r\n");
      out.write("   \t   \t \t\t</tr>\r\n");
      out.write("   \t   \t \t\t<tr>\r\n");
      out.write("   \t   \t \t\t\t<td>\r\n");
      out.write("   \t   \t \t\t\t\t<form action=\"");
      out.print(request.getContextPath());
      out.write("/Currentstatus\" method=\"post\">\t\r\n");
      out.write("   \t   \t \t\t\t\t\t<input type=\"hidden\" name=\"booth_no\" value=\"");
      out.print(b_no);
      out.write("\">\r\n");
      out.write("   \t\t\t\t\t\t\t<input type=\"image\" src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/currentstatus.png\" \r\n");
      out.write("   \t\t\t\t\t\t\t\t\tonmouseover=\"this.src='");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/currentstatus-click.png'\"\r\n");
      out.write("   \t   \t \t\t\t\t\t\t\tonmouseout=\"this.src='");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/currentstatus.png'\"/>\r\n");
      out.write("   \t   \t \t\t\t\t</form>\r\n");
      out.write("   \t   \t \t\t\t</td>\r\n");
      out.write("   \t   \t \t\t</tr>\r\n");
      out.write("   \t   \t \t\t\r\n");
      out.write("   \t   \t \t\t\r\n");
      out.write("   \t   \t \t\t");
      out.write("\r\n");
      out.write("   \t   \t \t</table>\r\n");
      out.write("\t\t</center>\t\t\r\n");
      out.write("\t</div>\r\n");
      out.write("\t\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
      out.write("     \r\n");
      out.write("  \r\n");
      out.write("   \r\n");
      out.write("       \r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("<html>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("<title>Insert title here</title>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<link rel=\"Stylesheet\" type=\"text/css\" href=\"Officer.css\">\r\n");
      out.write("\t\t<style type=\"text/css\">\r\n");
      out.write("#content{\r\n");
      out.write("margin-right:20%;\r\n");
      out.write("}\r\n");
      out.write("</style>\r\n");
      out.write("</head>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<body>\r\n");
      out.write("\r\n");
      out.write("<div id=\"content\">\r\n");
      out.write("<br><br>\r\n");
      out.write("<center>\r\n");
      out.write("<img src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/Manager/currentststus-logo.png\">\r\n");
      out.write("<br><br>\r\n");
      out.write("\t<table border=\"1\" width=\"400\" style=\"font-family: cambria; font-weight: bold;\">\r\n");
      out.write("\t\t<tr style=\"background-color:lightblue;color:black;\">\r\n");
      out.write("\t\t\t<td>CANDIDATE NAME</td>\r\n");
      out.write("\t\t\t<td>NUMBER OF VOTES</td>\r\n");
      out.write("\t\t</tr>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write('\r');
      out.write('\n');
 
		String booth_code=request.getParameter("booth_code");
		String no_votes=request.getParameter("no_votes");
		System.out.println("booth_code="+booth_code);
		sql1="select E_D_code from m_booth_manager where b_code='"+booth_code+"'";
		con1=DBConnection.getServerConnection();
		st1=con1.createStatement();
		rs1=st1.executeQuery(sql1);
		while(rs1.next())
		{
			e_d_code=rs1.getString(1);
		}
		sql2="select c.C_name,v.No_votes from m_candidate c left outer join m_votes v on c.C_code=v.C_code where c.E_D_code='"+e_d_code+"'";
		rs2=st1.executeQuery(sql2);	
		while(rs2.next())
		{
      out.write("\t\t\t\t\r\n");
      out.write("\t\t<tr>\r\n");
      out.write("\t\t\t<td>");
      out.print(rs2.getString(1));
      out.write("</td>\r\n");
      out.write("\t\t\t");
				
				if(rs2.getString(2)==null)
				{
					Paillier paillier=new Paillier();	
					n=paillier.Encryption(n);
					empty_code=n.toString();
				}
				else
				{
					empty_code=rs2.getString(2);
				}
			
      out.write("\r\n");
      out.write("\t\t\t<td><input type=\"text\" value=\"");
      out.print(empty_code);
      out.write("\" style=\"width:240px; color: red;\" readonly=\"readonly\"></td>\r\n");
      out.write("\t\t</tr>\r\n");
	}
      out.write("\r\n");
      out.write("\t</table>\r\n");
      out.write("\t<br>\r\n");
      out.write("\t<font style=\"font-family:cambria; font-weight:bold; color:black;\">\r\n");
      out.write("\t\tTOTAL NUMBER OF VOTES :\r\n");
      out.write("\t</font>\r\n");
      out.write("\t<font style=\"font-family:cambria; font-weight:bold; color:red;\">\r\n");
      out.write("\t\t<u>");
      out.print(no_votes);
      out.write("</u>\t\r\n");
      out.write("\t</font><br><br>\r\n");
      out.write("\t<p>\r\n");
      out.write("\t\t<font style=\"font-family:cambria; font-weight:bold; color:black;\">\r\n");
      out.write("\t\t\tNOTE :&emsp;\r\n");
      out.write("\t\t</font>\r\n");
      out.write("\t\t<font style=\"font-family:cambria; font-weight:bold; color:red;\">\r\n");
      out.write("\t\t\tUSING HOMOMORPHIC ENCRYPTION TOTAL NUMBER OF VOTES ARE<br>\r\n");
      out.write("\t\t</font>\r\n");
      out.write("\t</p>\r\n");
      out.write("</center>\r\n");
      out.write("<font style=\"font-family:cambria; font-weight:bold; color:red;\">\r\n");
      out.write("\t&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;\r\n");
      out.write("\tSUMED USING ENCRYPTED DATA WITHOUT DECRPTING<br>\r\n");
      out.write("</font>\r\n");
      out.write("</div>\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
        else log(t.getMessage(), t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
