package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class index1_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("<html>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<head>\r\n");
      out.write("\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
      out.write("\t<title>ONLINE POLLING</title>\t\t\t\t\r\n");
      out.write("</head>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<SCRIPT type=\"text/javascript\">\r\n");
      out.write("  \twindow.history.forward();\r\n");
      out.write("   \tfunction noBack() { window.history.forward(); }\r\n");
      out.write("</SCRIPT>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<script src=\"");
      out.print(request.getContextPath() );
      out.write("/Files/JS/jquery-1.6.4.min.js\" type=\"text/javascript\"></script>\r\n");
      out.write("\t\t<script type=\"text/javascript\">\r\n");
      out.write("\t\t$(document).ready(function(){\r\n");
      out.write("\t\t\t$(\".container .TabMenu span:first\").addClass(\"selector\");\r\n");
      out.write("\t\t\t\t$(\".container .TabMenu span\").mouseover(function(){\r\n");
      out.write("\t\t\t\t\t\t$(this).addClass(\"hovering\");\r\n");
      out.write("\t\t\t\t});\t\r\n");
      out.write("\t\t\t\t$(\".container .TabMenu span\").mouseout(function(){\r\n");
      out.write("\t\t\t\t\t$(this).removeClass(\"hovering\");\r\n");
      out.write("\t\t\t\t});\t\t\t\t\r\n");
      out.write("\t\t\t\t$(\".container .TabMenu span\").click(function(){\r\n");
      out.write("\t\t\t\t$(\".selector\").removeClass(\"selector\");\r\n");
      out.write("\t\t\t\t$(this).addClass(\"selector\");\r\n");
      out.write("\t\t\t\t\tvar TabWidth = $(\".TabContent:first\").width();\r\n");
      out.write("\t\t\t\t\tif(parseInt($(\".TabContent:first\").css(\"margin-left\")) > 0)\r\n");
      out.write("\t\t\t\t\t\tTabWidth += parseInt($(\".TabContaent:first\").css(\"margin-left\"));\r\n");
      out.write("\t\t\t\t\tif(parseInt($(\".TabContent:first\").css(\"margin-right\")) >0)\r\n");
      out.write("\t\t\t\t\t\tTabWidth += parseInt($(\".TabContent:first\").css(\"margin-right\"));\r\n");
      out.write("\t\t\t\t\tvar newLeft = -1* $(\"span\").index(this) * TabWidth;\r\n");
      out.write("\t\t\t\t\t$(\".AllTabs\").animate({\r\n");
      out.write("\t\t\t\t\t\tleft: + newLeft + \"px\"\r\n");
      out.write("\t\t\t\t\t},1000);\r\n");
      out.write("\t\t\t\t});\r\n");
      out.write("\t\t\t});\r\n");
      out.write("</script>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("    \twindow.history.forward();\r\n");
      out.write("    \tfunction noBack() { window.history.forward(); }\r\n");
      out.write("</script>\r\n");
      out.write("<style>\r\n");
      out.write("h1{\r\n");
      out.write("font-size:50px;\r\n");
      out.write("text-align:center;\r\n");
      out.write("height:50px;\r\n");
      out.write("}\r\n");
      out.write("/* Background styles */\r\n");
      out.write("body {\r\n");
      out.write("   /*  background-image: url('https://images.unsplash.com/photo-1519681393784-d120267933ba?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1124&q=100'); */\r\n");
      out.write(" background-color:#32a87d;\r\n");
      out.write("    background-position: center;\r\n");
      out.write("    background-repeat: no-repeat;\r\n");
      out.write("    width:100%;\r\n");
      out.write("    background-size:cover;\r\n");
      out.write("    \r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("/* Glassmorphism card effect */\r\n");
      out.write(".card {   \r\n");
      out.write("       backdrop-filter: blur(16px) saturate(180%);\r\n");
      out.write("    -webkit-backdrop-filter: blur(16px) saturate(180%);\r\n");
      out.write("    background-color: rgba(255, 255, 255, 0.75);\r\n");
      out.write("    border-radius: 30px;\r\n");
      out.write("    border: 1px solid rgba(209, 213, 219, 0.3);\r\n");
      out.write("     margin-top:80px;\r\n");
      out.write("     margin-right:100px;\r\n");
      out.write("     margin-left:35%;\r\n");
      out.write(" \r\n");
      out.write("}\r\n");
      out.write(".Tapcontent{\r\n");
      out.write("margin-right:60px;\r\n");
      out.write("}\r\n");
      out.write(".outset{border-style: outset;\r\n");
      out.write("margin-left:150px;}\r\n");
      out.write("button:hover{\r\n");
      out.write("color:green;\r\n");
      out.write("}\r\n");
      out.write("#header{\r\n");
      out.write("margin-top:20px;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("/* Generated by https://generator.ui.glass/ */\r\n");
      out.write("</style>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<link rel=\"stylesheet\" href=\"");
      out.print(request.getContextPath());
      out.write("/Files/CSS/login.css\" type=\"text/css\"/>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<body background=\"Files/images/index/vote4.jpg\">\r\n");
      out.write("<!-- <body background=\"Files/images/index/online.jpg\">\r\n");
      out.write("<!-- <div style=\"background-image: url(Files/images/index/titlebar.png);\r\n");
      out.write("\t\t\t\twidth:1000px;\r\n");
      out.write("\t\t\t\theight:160px;\r\n");
      out.write("\t\t\t\twidth:1000;\r\n");
      out.write("\t\t\t\theight:160;\"><br>\r\n");
      out.write("\t<center>\r\n");
      out.write("\t\t<img src=\"Files/images/index/title.png\"><br><br>\r\n");
      out.write("\t</center>\t\t\t\t\t\t\t\r\n");
      out.write("</div > -->\r\n");
      out.write("\t<div id=\"header\">\r\n");
      out.write("\t\t<br>\t\t\t\t\r\n");
      out.write("\t\t<center>\r\n");
      out.write("\t\t\t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/index/title.png\"><br><br>\r\n");
      out.write("\t\t\t");
      out.write("\r\n");
      out.write("\t\t</center>\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t</div>\r\n");
      out.write("\r\n");
      out.write("\t<div style=\"\r\n");
      out.write("\t\t\t\tfloat:left;\">\r\n");
      out.write("\t\t\t\t&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;\r\n");
      out.write("\t</div>\r\n");
      out.write("\t<!-- <div style=\"width:275;\r\n");
      out.write("\t\t\t\theight:285;\r\n");
      out.write("\t\t\t\tfloat:right;\">\r\n");
      out.write("\t\t\t\t<br><br><br><br>\r\n");
      out.write("\t\t\t\t<img src=\"Files/images/index/onlinevote.png\">\r\n");
      out.write("\t</div> -->\r\n");
      out.write("\t<div class=\"card\" style=\"width:400px;\r\n");
      out.write("\t\t\t\theight:380px;\r\n");
      out.write("\t\t\t\tfloat:left;\r\n");
      out.write("\t\t\t\tz-index:-1px;\r\n");
      out.write("\t\t\t\t margin-right:60%;\">\r\n");
      out.write("\t</div>\r\n");
      out.write("\t\r\n");
      out.write("\t<div class=\"container\"style=\"margin-left:27%;\">\r\n");
      out.write("\t\t<div class=\"TabMenu\"><br>\r\n");
      out.write("\t\t\t<center>\t\t\r\n");
      out.write("\t\t\t");
      out.write("\r\n");
      out.write("\t\t\t\t<span>\r\n");
      out.write("\t\t\t\t\t<img src=\"");
      out.print(request.getContextPath());
      out.write("/Files/images/index/download.png\" height=\"80\" width=\"80\" /><br>&emsp;Booth<br>&emsp;&nbsp;Manager\r\n");
      out.write("\t\t\t\t</span>\r\n");
      out.write("\t\t\t</center><br><br>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t<div class=\"ContentFrame\">\r\n");
      out.write("\t\t\t<div class=\"AllTabs\">\r\n");
      out.write("\t\t\t");
      out.write("\r\n");
      out.write("\t\t\t\t<div class=\"TabContent\">\r\n");
      out.write("\t\t\t\t\t&emsp;&emsp;&emsp;&emsp;<img src=\"Files/images/index/managerlogin.png\"><br><br>\r\n");
      out.write("\t\t\t\t\t<form method=\"post\" id=\"login\" action=\"");
      out.print(request.getContextPath() );
      out.write("/Managerlogin\">\r\n");
      out.write("\t\t\t\t\t\t<center>\r\n");
      out.write("\t\t\t\t\t\t\t<table>\r\n");
      out.write("\t\t\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t<td width=20% ></td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t<td><b><font size=\"4\">Login id</font></b></td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t<td>:</td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t<td><input type=\"text\" name=\"manager_id\" required=\"required\" style=\"border:1px solid #F298EE;\"></input></td>\r\n");
      out.write("\t\t\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t<td width=20% ></td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t<td><b><font size=\"4\">Password</font></b></td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t<td>:</td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t<td><input type=\"password\" name=\"manager_pwd\" required=\"required\" style=\"border:1px solid #F298EE;\"></input></td>\r\n");
      out.write("\t\t\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t\t</table>\t\r\n");
      out.write("\t\t\t\t\t\t\t<br>&emsp;&emsp;&emsp;&emsp;\r\n");
      out.write("\t\t\t\t\t\t\t<input type=\"image\" src=\"Files/images/index/button.png\" onmouseover=\"this.src='Files/images/index/buttonclick.png'\" onmouseout=\"this.src='Files/images/index/button.png'\">\r\n");
      out.write("\t\t\t\t\t\t</center>\t\t\r\n");
      out.write("\t\t\t\t\t</form>\r\n");
      out.write("\t\t\t\t\t<form  method=\"post\" action=\"");
      out.print(request.getContextPath());
      out.write("/index.jsp\">\r\n");
      out.write("      <button class=\"outset\">Officer Login ?</button>\r\n");
      out.write("      </form> \r\n");
      out.write("\t\t\t\t</div>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t</div>\t\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\t\t\t\r\n");
      out.write("\t\t\t\r\n");
	String status=null;
	status=(String)request.getAttribute("Status");				
	if(status==null)
	{
			
	}
	else
	{
      out.write("\r\n");
      out.write("\t\t<script type=\"text/javascript\">\r\n");
      out.write("\t\t\talert(\"Sorry,your Id and Password is mismatched\");\r\n");
      out.write("\t\t</script>\r\n");
	}
      out.write("\t\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
        else log(t.getMessage(), t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
