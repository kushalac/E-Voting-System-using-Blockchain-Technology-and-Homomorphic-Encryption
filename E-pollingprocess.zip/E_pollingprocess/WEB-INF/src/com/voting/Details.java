package com.voting;

public class Details 
{
	

}
